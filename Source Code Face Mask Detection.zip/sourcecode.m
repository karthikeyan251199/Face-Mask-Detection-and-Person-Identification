% 
%Face Recognition based on Wavelet and Neural Networks
% 
% Feel Free To visit us :visi
% http://matlab-recognition-code.com/face-recognition-based-on-wavelet-and-neural-networks-matlab-code/
%
% 
% Face recognition based on Wavelet
%                                 and Neural Networks
%                               - High recognition rate
%                               - Easy and intuitive GUI
%
% For more informations please email me ( hatem_hajri@matlab-recognition-code.com )
