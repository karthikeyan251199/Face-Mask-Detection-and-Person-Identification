# Image-Matching-With-Reference-Image---MATLAB-
This program has a GUI which runs and takes one image as a initial input and another image as a reference image 
and matches contrast of first image with the second image. 
The GUI also can produce grayscale of those images and histogram of both of the images. 
After matching both of the histograms, it shows the final histogram of the final image. 

Finally it let you to save the final image. 

There are some images with the project files. 

The folder contains a .m file and a .fig file. Both of them are necessary to run the code perfectly. 
