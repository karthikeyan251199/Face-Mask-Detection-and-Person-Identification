f=500;
t=[0:0.0001:.01];
y=sin(2*pi*f*t);
plot(t,y)